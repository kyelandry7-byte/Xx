# MatchLab Football v5 — BetPawa Cameroun + historique

Application Streamlit en français pour analyser les marchés de football 1X2, Plus/Moins buts et BTTS, comparer des cotes BetPawa saisies par l'utilisateur, puis enregistrer les analyses et évaluer leurs résultats historiques.

## Fonctionnalités v5
- Modèle de buts Poisson (xG manuels ou statistiques d'équipe via API-Football avec clé API).
- Saisie manuelle des cotes BetPawa Cameroun et import de cotes CSV.
- Enregistrement de chaque analyse avant le match : date, équipes, xG, probabilités, cotes et sélection retenue au meilleur EV estimé.
- Saisie du score final après le match.
- Tableau historique, taux de réussite, bilan net et ROI simulé sur une mise fixe de 1 000 FCFA.
- Export complet CSV et restauration depuis un CSV précédemment exporté.

## Lancer sur ordinateur
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Utiliser sur Android
Déployer le dépôt GitHub sur https://share.streamlit.io/ puis ouvrir l'URL `streamlit.app` dans Chrome. Streamlit documente le déploiement dans sa documentation officielle.

## Important pour l'historique
Les données sont enregistrées dans `matchlab_history.sqlite3`. Sur un hébergement cloud gratuit, le système de fichiers local ne doit pas être considéré comme un stockage permanent. Utilise régulièrement **Exporter tout l'historique en CSV** et garde les sauvegardes. Après une réinstallation ou un redéploiement, restaure le CSV depuis l'application. Pour un stockage permanent multi-appareils, il faudra connecter une base de données distante (par exemple PostgreSQL/Supabase) dans une version suivante.

## BetPawa
Les cotes sont saisies manuellement ou importées depuis un CSV; cette application ne contourne pas les protections du site et ne prétend pas disposer d'une API publique officielle BetPawa. Vérifie les cotes et les règles du marché dans le compte BetPawa Cameroun. La version actuelle ne place aucun pari.

## Limites méthodologiques
Le modèle de Poisson est une approximation, pas un modèle professionnel garanti. Le backtest évalue la sélection au meilleur EV estimé parmi les marchés renseignés à l'instant où l'analyse est sauvegardée. Les résultats sont simulés, à mise fixe de 1 000 FCFA, sans tenir compte des annulations, limites, changements de cote après enregistrement ni de toute autre condition spécifique. L'historique est petit au départ : ne tire pas de conclusion solide sur quelques matchs. Aucun résultat ne garantit les performances futures.
