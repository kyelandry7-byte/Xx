import math
import requests
import pandas as pd
import streamlit as st

st.set_page_config(page_title="MatchLab Football", page_icon="⚽", layout="wide")
API_BASE = "https://v3.football.api-sports.io"

@st.cache_data(ttl=900, show_spinner=False)
def api_get(endpoint, api_key, params):
    response = requests.get(f"{API_BASE}/{endpoint}", headers={"x-apisports-key": api_key}, params=params, timeout=20)
    response.raise_for_status()
    data = response.json()
    if data.get("errors"):
        raise ValueError(str(data["errors"]))
    return data.get("response", [])

def poisson_pmf(k, lam):
    return math.exp(-lam) * (lam ** k) / math.factorial(k)

def score_matrix(home_xg, away_xg, max_goals=10):
    hp = [poisson_pmf(i, home_xg) for i in range(max_goals + 1)]
    ap = [poisson_pmf(i, away_xg) for i in range(max_goals + 1)]
    return [[h * a for a in ap] for h in hp]

def calculate_probabilities(home_xg, away_xg, max_goals=10):
    matrix = score_matrix(home_xg, away_xg, max_goals)
    result = {"1": 0.0, "X": 0.0, "2": 0.0, "BTTS Oui": 0.0}
    for h, row in enumerate(matrix):
        for a, p in enumerate(row):
            if h > a: result["1"] += p
            elif h == a: result["X"] += p
            else: result["2"] += p
            if h > 0 and a > 0: result["BTTS Oui"] += p
    for line in (1.5, 2.5, 3.5, 4.5):
        over = sum(p for h, row in enumerate(matrix) for a, p in enumerate(row) if h + a > line)
        result[f"Over {line}"] = over
        result[f"Under {line}"] = 1 - over
    result["BTTS Non"] = 1 - result["BTTS Oui"]
    return result

def fair_odds(p):
    return 1 / p if p > 0 else float("inf")

def parse_average(stats, side, kind):
    # API-Football returns averages as strings in goals.for.average.home/away
    try:
        value = stats["goals"][kind]["average"][side]
        return float(value) if value not in (None, "-") else None
    except (KeyError, TypeError, ValueError):
        return None

def get_team_stats(api_key, league_id, season, team_id):
    rows = api_get("teams/statistics", api_key, {"league": league_id, "season": season, "team": team_id})
    if not rows:
        raise ValueError("Aucune statistique retournée pour cette équipe.")
    # API-Football's team statistics endpoint commonly returns a JSON object,
    # while fixture endpoints return a list. Support both response shapes.
    if isinstance(rows, dict):
        return rows
    return rows[0]

st.title("⚽ MatchLab Football")
st.caption("Analyse probabiliste 1X2, buts, scores exacts et comparaison des cotes. Les résultats restent des estimations, jamais des garanties.")

with st.sidebar:
    st.header("Source des données")
    mode = st.radio("Mode", ["Saisie manuelle", "Données API-Football"], index=0)
    api_key = ""
    league_id = 39
    season = 2026
    match_date = None
    if mode == "Données API-Football":
        st.markdown("Obtiens une clé API sur [API-Football](https://www.api-football.com/), puis colle-la ici.")
        api_key = st.text_input("Clé API (non enregistrée par l'application)", type="password")
        league_id = st.number_input("ID de ligue", min_value=1, value=39, step=1, help="Exemple : 39 = Premier League anglaise.")
        season = st.number_input("Saison (année de début)", min_value=2010, max_value=2035, value=2026, step=1)
        match_date = st.date_input("Date des matchs")
    st.divider()
    st.header("Paramètres du modèle")
    home = st.text_input("Équipe à domicile", "Équipe domicile")
    away = st.text_input("Équipe à l'extérieur", "Équipe extérieure")
    home_xg = st.slider("Buts attendus domicile", 0.10, 4.50, 1.55, 0.05)
    away_xg = st.slider("Buts attendus extérieur", 0.10, 4.50, 1.10, 0.05)

if mode == "Données API-Football":
    st.subheader("Importer un match depuis les données de football")
    if not api_key:
        st.info("Ajoute ta clé API dans le menu de gauche pour charger les matchs. Tu peux toujours utiliser le mode manuel.")
    else:
        try:
            fixtures = api_get("fixtures", api_key, {"date": str(match_date), "league": int(league_id), "season": int(season)})
            if not fixtures:
                st.warning("Aucun match trouvé pour cette ligue, cette saison et cette date. Vérifie les paramètres ou essaie une autre date.")
            else:
                choices = {f"{f['teams']['home']['name']} — {f['teams']['away']['name']} | {f['fixture']['date'][:16].replace('T',' ')}": f for f in fixtures}
                selected_label = st.selectbox("Choisir un match", list(choices.keys()))
                if st.button("Charger les statistiques des équipes", type="primary"):
                    fixture = choices[selected_label]
                    hteam, ateam = fixture["teams"]["home"], fixture["teams"]["away"]
                    with st.spinner("Récupération des statistiques…"):
                        hs = get_team_stats(api_key, int(league_id), int(season), hteam["id"])
                        aws = get_team_stats(api_key, int(league_id), int(season), ateam["id"])
                    # Attack rates and opponent defensive rates, split by venue.
                    h_for = parse_average(hs, "home", "for")
                    a_against = parse_average(aws, "away", "against")
                    a_for = parse_average(aws, "away", "for")
                    h_against = parse_average(hs, "home", "against")
                    if None in (h_for, a_against, a_for, h_against):
                        st.error("Les moyennes de buts domicile/extérieur sont indisponibles. Utilise la saisie manuelle pour ce match.")
                    else:
                        st.session_state["home"] = hteam["name"]
                        st.session_state["away"] = ateam["name"]
                        st.session_state["home_xg"] = max(0.1, min(4.5, (h_for + a_against) / 2))
                        st.session_state["away_xg"] = max(0.1, min(4.5, (a_for + h_against) / 2))
                        st.success("Statistiques chargées. Les estimations ont été mises à jour. Tu peux aussi les ajuster dans le menu de gauche.")
                        st.rerun()
        except Exception as e:
            st.error(f"Impossible de charger les données : {e}. Vérifie ta clé API, les quotas et la ligue/saison choisies.")

# Keep values loaded from API across reruns, while retaining manual controls.
home = st.session_state.get("home", home)
away = st.session_state.get("away", away)
home_xg = st.session_state.get("home_xg", home_xg)
away_xg = st.session_state.get("away_xg", away_xg)
probs = calculate_probabilities(home_xg, away_xg)

st.subheader("Résumé du match")
c1, c2, c3 = st.columns(3)
c1.metric(f"Victoire {home}", f"{probs['1']*100:.1f}%")
c2.metric("Match nul", f"{probs['X']*100:.1f}%")
c3.metric(f"Victoire {away}", f"{probs['2']*100:.1f}%")
st.write(f"Buts attendus utilisés : **{home} {home_xg:.2f}** — **{away_xg:.2f} {away}**")

st.subheader("Marché 1X2")
rows = []
for key, label in [("1", f"Victoire {home}"), ("X", "Match nul"), ("2", f"Victoire {away}")]:
    p = probs[key]
    rows.append({"Sélection": label, "Probabilité modèle": f"{p*100:.1f}%", "Cote juste estimée": f"{fair_odds(p):.2f}"})
st.dataframe(pd.DataFrame(rows), hide_index=True, use_container_width=True)

st.subheader("Over / Under — total de buts")
rows = []
for line in (1.5, 2.5, 3.5, 4.5):
    for key in (f"Over {line}", f"Under {line}"):
        p = probs[key]
        rows.append({"Marché": key, "Probabilité modèle": f"{p*100:.1f}%", "Cote juste estimée": f"{fair_odds(p):.2f}"})
st.dataframe(pd.DataFrame(rows), hide_index=True, use_container_width=True)

st.subheader("Les deux équipes marquent (BTTS)")
rows = []
for key in ("BTTS Oui", "BTTS Non"):
    p = probs[key]
    rows.append({"Marché": key, "Probabilité modèle": f"{p*100:.1f}%", "Cote juste estimée": f"{fair_odds(p):.2f}"})
st.dataframe(pd.DataFrame(rows), hide_index=True, use_container_width=True)

st.subheader("Cotes betPawa — comparaison avec le modèle")
st.caption("Les cotes betPawa sont saisies depuis le site ou l'application de ton pays. Cette version ne prétend pas les récupérer automatiquement : il faut un flux officiel/autorisé pour cela.")
with st.expander("Ouvrir le site betPawa", expanded=False):
    st.write("Ouvre le site betPawa officiel de ton pays, puis recopie les cotes affichées pour le match sélectionné.")
    st.link_button("Ouvrir betPawa", "https://www.betpawa.cm/", use_container_width=True)

# Keep a consistent internal mapping for manual and CSV odds.
market_probabilities = {
    "1X2|1": probs["1"], "1X2|X": probs["X"], "1X2|2": probs["2"],
    "Over/Under 1.5|Over 1.5": probs["Over 1.5"], "Over/Under 1.5|Under 1.5": probs["Under 1.5"],
    "Over/Under 2.5|Over 2.5": probs["Over 2.5"], "Over/Under 2.5|Under 2.5": probs["Under 2.5"],
    "Over/Under 3.5|Over 3.5": probs["Over 3.5"], "Over/Under 3.5|Under 3.5": probs["Under 3.5"],
    "Over/Under 4.5|Over 4.5": probs["Over 4.5"], "Over/Under 4.5|Under 4.5": probs["Under 4.5"],
    "BTTS|Oui": probs["BTTS Oui"], "BTTS|Non": probs["BTTS Non"],
}

def build_comparison(entries):
    """entries: (market, selection, decimal odds, match name) tuples."""
    grouped = {}
    for market, selection, odds_value, match_name in entries:
        grouped.setdefault((match_name, market), []).append(float(odds_value))
    result = []
    for market, selection, odds_value, match_name in entries:
        key = f"{market}|{selection}"
        p_model = market_probabilities.get(key)
        if p_model is None or odds_value is None or float(odds_value) <= 1.0:
            continue
        odds_value = float(odds_value)
        implied = 1 / odds_value
        group_odds = grouped.get((match_name, market), [])
        overround = (sum(1 / o for o in group_odds) - 1) * 100 if len(group_odds) >= 2 else None
        raw_total = sum(1 / o for o in group_odds) if group_odds else 0
        normalized = (implied / raw_total) if raw_total > 0 else None
        result.append({
            "Match": match_name,
            "Marché": market,
            "Sélection": selection,
            "Probabilité modèle": f"{p_model*100:.1f}%",
            "Cote betPawa": f"{odds_value:.2f}",
            "Probabilité implicite brute": f"{implied*100:.1f}%",
            "Probabilité implicite corrigée marge": f"{normalized*100:.1f}%" if normalized is not None else "—",
            "Cote juste modèle": f"{(1/p_model):.2f}" if p_model > 0 else "—",
            "EV théorique": f"{(p_model*odds_value-1)*100:+.1f}%",
            "Marge marché": f"{overround:+.1f}%" if overround is not None else "—",
        })
    return pd.DataFrame(result)

with st.form("betpawa_odds_form"):
    st.markdown(f"**Match analysé : {home} — {away}**")
    st.caption("Entre les cotes décimales exactement comme elles apparaissent sur betPawa. Laisse les marchés que tu n'as pas sous les yeux à leur valeur par défaut uniquement pour tester l'application.")
    st.markdown("**1X2**")
    c1, c2, c3 = st.columns(3)
    bp_home = c1.number_input(f"1 · {home}", min_value=1.01, max_value=100.0, value=2.10, step=0.01)
    bp_draw = c2.number_input("X · Nul", min_value=1.01, max_value=100.0, value=3.20, step=0.01)
    bp_away = c3.number_input(f"2 · {away}", min_value=1.01, max_value=100.0, value=3.40, step=0.01)
    st.markdown("**Total de buts — Plus / Moins**")
    ou_odds = {}
    for line in (1.5, 2.5, 3.5, 4.5):
        c1, c2 = st.columns(2)
        ou_odds[(f"Over/Under {line}", f"Over {line}")] = c1.number_input(f"Plus de {line}", min_value=1.01, max_value=100.0, value={1.5:1.25,2.5:1.90,3.5:3.20,4.5:5.50}[line], step=0.01, key=f"bp_over_{line}")
        ou_odds[(f"Over/Under {line}", f"Under {line}")] = c2.number_input(f"Moins de {line}", min_value=1.01, max_value=100.0, value={1.5:3.60,2.5:1.85,3.5:1.35,4.5:1.12}[line], step=0.01, key=f"bp_under_{line}")
    st.markdown("**Les deux équipes marquent (BTTS)**")
    c1, c2 = st.columns(2)
    bp_btts_yes = c1.number_input("Oui", min_value=1.01, max_value=100.0, value=1.80, step=0.01)
    bp_btts_no = c2.number_input("Non", min_value=1.01, max_value=100.0, value=1.95, step=0.01)
    bp_submit = st.form_submit_button("Comparer les cotes betPawa", type="primary", use_container_width=True)

if bp_submit:
    entries = [
        ("1X2", "1", bp_home, f"{home} — {away}"),
        ("1X2", "X", bp_draw, f"{home} — {away}"),
        ("1X2", "2", bp_away, f"{home} — {away}"),
    ]
    entries.extend((market, selection, price, f"{home} — {away}") for (market, selection), price in ou_odds.items())
    entries.extend([("BTTS", "Oui", bp_btts_yes, f"{home} — {away}"), ("BTTS", "Non", bp_btts_no, f"{home} — {away}")])
    comparison = build_comparison(entries)
    st.session_state["betpawa_comparison"] = comparison
    st.dataframe(comparison, hide_index=True, use_container_width=True)
    st.caption("EV théorique = probabilité du modèle × cote − 1. La probabilité corrigée de la marge est normalisée à partir des sélections saisies dans le même marché. Une EV positive n'est ni un pronostic sûr ni une garantie de gain.")
    st.download_button("Télécharger la comparaison CSV", comparison.to_csv(index=False).encode("utf-8-sig"), file_name="matchlab_betpawa_comparison.csv", mime="text/csv", use_container_width=True)

with st.expander("Importer les cotes betPawa depuis un CSV"):
    st.write("L'import CSV calcule aussi la comparaison. Le fichier doit contenir les colonnes `match`, `market`, `selection`, `odds`. Les valeurs de marché/selection reconnues sont indiquées dans le modèle CSV ci-dessous.")
    template = pd.DataFrame([
        {"match": f"{home} - {away}", "market": "1X2", "selection": "1", "odds": 2.10},
        {"match": f"{home} - {away}", "market": "1X2", "selection": "X", "odds": 3.20},
        {"match": f"{home} - {away}", "market": "1X2", "selection": "2", "odds": 3.40},
        {"match": f"{home} - {away}", "market": "Over/Under 2.5", "selection": "Over 2.5", "odds": 1.90},
        {"match": f"{home} - {away}", "market": "Over/Under 2.5", "selection": "Under 2.5", "odds": 1.85},
        {"match": f"{home} - {away}", "market": "BTTS", "selection": "Oui", "odds": 1.80},
        {"match": f"{home} - {away}", "market": "BTTS", "selection": "Non", "odds": 1.95},
    ])
    st.download_button("Télécharger le modèle CSV", template.to_csv(index=False).encode("utf-8-sig"), "modele_cotes_betpawa.csv", "text/csv", use_container_width=True)
    uploaded = st.file_uploader("Sélectionner un CSV de cotes", type=["csv"], key="betpawa_csv_v4")
    if uploaded is not None:
        try:
            imported = pd.read_csv(uploaded)
            required = {"match", "market", "selection", "odds"}
            if not required.issubset(imported.columns):
                st.error("Colonnes attendues : match, market, selection, odds.")
            else:
                imported["odds"] = pd.to_numeric(imported["odds"], errors="coerce")
                imported["market"] = imported["market"].astype(str).str.strip()
                imported["selection"] = imported["selection"].astype(str).str.strip()
                imported["match"] = imported["match"].astype(str).str.strip()
                imported = imported.dropna(subset=["odds"])
                imported = imported[imported["odds"] > 1.0]
                csv_entries = [(r.market, r.selection, float(r.odds), r.match) for r in imported.itertuples()]
                csv_comparison = build_comparison(csv_entries)
                if csv_comparison.empty:
                    st.warning("Aucune ligne reconnue. Vérifie les libellés `market` et `selection` à l'aide du modèle CSV.")
                else:
                    st.dataframe(csv_comparison, hide_index=True, use_container_width=True)
                    st.download_button("Télécharger l'analyse des cotes importées", csv_comparison.to_csv(index=False).encode("utf-8-sig"), "analyse_cotes_betpawa_importees.csv", "text/csv", mime="text/csv", use_container_width=True)
        except Exception as e:
            st.error(f"Impossible de lire ce CSV : {e}")

st.subheader("Évaluer une cote de bookmaker")
market_options = {
    f"Victoire {home}": probs["1"], "Match nul": probs["X"], f"Victoire {away}": probs["2"],
    **{f"Over {line} buts": probs[f"Over {line}"] for line in (1.5, 2.5, 3.5, 4.5)},
    **{f"Under {line} buts": probs[f"Under {line}"] for line in (1.5, 2.5, 3.5, 4.5)},
    "BTTS Oui": probs["BTTS Oui"], "BTTS Non": probs["BTTS Non"]}
with st.form("odds_form"):
    selected = st.selectbox("Marché à évaluer", list(market_options.keys()))
    odds = st.number_input("Cote décimale du bookmaker", min_value=1.01, max_value=100.0, value=1.90, step=0.01)
    bankroll = st.number_input("Budget de référence (facultatif)", min_value=0.0, value=100.0, step=10.0)
    stake_pct = st.slider("Mise simulée (% du budget)", 0.0, 5.0, 1.0, 0.25)
    submitted = st.form_submit_button("Calculer la valeur", type="primary")
if submitted:
    p = market_options[selected]
    implied = 1 / odds
    ev = (p * odds - 1) * 100
    stake = bankroll * stake_pct / 100
    expected_net = stake * (p * (odds - 1) - (1 - p))
    a, b, c, d = st.columns(4)
    a.metric("Probabilité modèle", f"{p*100:.1f}%")
    b.metric("Probabilité implicite brute", f"{implied*100:.1f}%")
    c.metric("Espérance théorique", f"{ev:+.1f}%")
    d.metric("Gain/perte moyen simulé", f"{expected_net:+.2f}")
    if ev > 0:
        st.success("La cote est supérieure à la cote juste estimée selon ce modèle — ce n'est pas une garantie de gain.")
    else:
        st.warning("Selon ce modèle, la cote ne présente pas d'espérance positive estimée.")

st.subheader("Scores exacts les plus probables")
mat = score_matrix(home_xg, away_xg, 8)
scores = []
for h, row in enumerate(mat):
    for a, p in enumerate(row):
        scores.append({"Score": f"{h}–{a}", "Probabilité": p})
scores = sorted(scores, key=lambda x: x["Probabilité"], reverse=True)[:10]
st.dataframe(pd.DataFrame([{"Score": x["Score"], "Probabilité": f"{x['Probabilité']*100:.2f}%"} for x in scores]), hide_index=True, use_container_width=True)

with st.expander("Méthode et limites"):
    st.markdown("""
    - Le modèle suppose des buts distribués selon deux lois de Poisson indépendantes.
    - En mode API, les buts attendus sont approximés par la moyenne entre l'attaque d'une équipe à domicile/extérieur et les buts encaissés par l'adversaire dans la situation correspondante.
    - Ce n'est pas un modèle xG professionnel : il ne tient pas automatiquement compte des compositions, blessures, suspensions, météo, tactique ni de la force des adversaires.
    - Les cotes justes ne comprennent pas la marge du bookmaker. L'espérance théorique dépend entièrement de la qualité des probabilités estimées.
    - Commence par des simulations et des tests historiques. Ne mise pas de l'argent dont tu as besoin.
    """)
st.caption("MatchLab Football v5 · Outil d’analyse éducatif, sans garantie de résultat.")


# -----------------------------------------------------------------------------
# MATCHLAB v5: historical database + backtesting
# Local SQLite storage. On hosted deployments, export CSV backups regularly.
# -----------------------------------------------------------------------------
import sqlite3
import json
from datetime import date, datetime
from io import StringIO

DB_PATH = "matchlab_history.sqlite3"


def history_connect():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("""CREATE TABLE IF NOT EXISTS match_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        saved_at TEXT NOT NULL,
        match_date TEXT NOT NULL,
        home TEXT NOT NULL,
        away TEXT NOT NULL,
        home_xg REAL NOT NULL,
        away_xg REAL NOT NULL,
        probabilities_json TEXT NOT NULL,
        odds_json TEXT NOT NULL,
        selected_market TEXT,
        selected_pick TEXT,
        selected_odds REAL,
        selected_probability REAL,
        selected_ev REAL,
        home_goals INTEGER,
        away_goals INTEGER,
        result_status TEXT NOT NULL DEFAULT 'À régler'
    )""")
    conn.commit()
    return conn


def make_odds_dict(odds_1, odds_x, odds_2, ou_odds, btts_yes, btts_no):
    d = {"1X2|1": float(odds_1), "1X2|X": float(odds_x), "1X2|2": float(odds_2),
         "BTTS|Oui": float(btts_yes), "BTTS|Non": float(btts_no)}
    for (market, selection), price in ou_odds.items():
        d[f"{market}|{selection}"] = float(price)
    return d


def choose_best_value(probabilities, odds):
    candidates = []
    for key, price in odds.items():
        # Only known model markets are considered.
        market, selection = key.split("|", 1)
        if market == "1X2":
            p_model = probabilities.get(selection)
        elif market.startswith("Over/Under "):
            p_model = probabilities.get(selection)
        elif market == "BTTS":
            p_model = probabilities.get("BTTS Oui" if selection == "Oui" else "BTTS Non")
        else:
            p_model = None
        if p_model is not None and float(price) > 1:
            ev = float(p_model) * float(price) - 1
            candidates.append((ev, market, selection, float(price), float(p_model)))
    if not candidates:
        return (None, None, None, None, None)
    best = max(candidates, key=lambda item: item[0])
    # Save the highest estimated-EV selection, even if negative, so the test
    # can report the model's choice without retrospectively filtering outcomes.
    return best[1], best[2], best[3], best[4], best[0]


def result_for_pick(market, pick, hg, ag):
    total = hg + ag
    if market == "1X2":
        actual = "1" if hg > ag else ("X" if hg == ag else "2")
        return actual == pick
    if market.startswith("Over/Under "):
        line = float(market.replace("Over/Under ", ""))
        return (total > line) if pick.startswith("Over") else (total < line)
    if market == "BTTS":
        actual = "Oui" if hg > 0 and ag > 0 else "Non"
        return actual == pick
    return False


def get_history_df(conn):
    return pd.read_sql_query("SELECT * FROM match_history ORDER BY id DESC", conn)


st.divider()
st.header("🗂️ Historique et backtesting — v5")
st.caption("Enregistre chaque analyse avant le match, puis ajoute le score final. Le test utilise uniquement les probabilités et cotes sauvegardées à l'avance.")
conn = history_connect()

with st.expander("1. Enregistrer l'analyse actuelle", expanded=True):
    h_date = st.date_input("Date prévue du match", value=date.today(), key="history_match_date")
    st.write(f"**Match :** {home} — {away} | **xG modèle :** {home_xg:.2f} – {away_xg:.2f}")
    st.caption("Les cotes reprises ci-dessous sont les valeurs saisies dans le formulaire betPawa plus haut. Vérifie-les avant d'enregistrer.")
    current_odds = make_odds_dict(bp_home, bp_draw, bp_away, ou_odds, bp_btts_yes, bp_btts_no)
    best_market, best_pick, best_odds, best_p, best_ev = choose_best_value(probs, current_odds)
    if best_market is not None:
        st.write(f"Sélection au meilleur EV estimé au moment de l'enregistrement : **{best_market} · {best_pick}** — cote {best_odds:.2f}, EV {best_ev*100:+.1f}%. Cette sélection est figée dans l'historique.")
    odds_confirmed = st.checkbox("J’ai vérifié et saisi les cotes réelles affichées sur BetPawa Cameroun (pas les valeurs d’exemple).", key="history_odds_confirmed")
    if st.button("💾 Enregistrer cette analyse dans l'historique", type="primary", use_container_width=True):
        if not odds_confirmed:
            st.warning("Confirme que les cotes ont été vérifiées sur BetPawa Cameroun avant d’enregistrer l’analyse.")
        else:
            conn.execute("""INSERT INTO match_history
                (saved_at, match_date, home, away, home_xg, away_xg, probabilities_json, odds_json,
                 selected_market, selected_pick, selected_odds, selected_probability, selected_ev)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (datetime.now().isoformat(timespec="seconds"), str(h_date), str(home), str(away),
                 float(home_xg), float(away_xg), json.dumps(probs, ensure_ascii=False),
                 json.dumps(current_odds, ensure_ascii=False), best_market, best_pick, best_odds,
                 best_p, best_ev))
            conn.commit()
            st.success("Analyse enregistrée. Ajoute le score final après le match pour alimenter le backtesting.")
            st.rerun()

history = get_history_df(conn)
if not history.empty:
    total_saved = len(history)
    settled = history.dropna(subset=["home_goals", "away_goals"]).copy()
    c1, c2, c3 = st.columns(3)
    c1.metric("Analyses sauvegardées", total_saved)
    c2.metric("Matchs réglés", len(settled))
    c3.metric("En attente", total_saved-len(settled))

    with st.expander("2. Ajouter ou corriger le score final", expanded=False):
        pending = history[history["home_goals"].isna() | history["away_goals"].isna()]
        if pending.empty:
            st.info("Tous les matchs de l'historique ont un score final. Tu peux toujours exporter ou importer des données ci-dessous.")
        else:
            labels = {int(r.id): f"#{int(r.id)} · {r.match_date} · {r.home} — {r.away}" for r in pending.itertuples()}
            chosen_id = st.selectbox("Match à régler", list(labels.keys()), format_func=lambda x: labels[x])
            chosen = pending[pending["id"] == chosen_id].iloc[0]
            a, b = st.columns(2)
            final_h = a.number_input(f"Buts {chosen['home']}", min_value=0, max_value=30, value=0, step=1, key=f"final_h_{chosen_id}")
            final_a = b.number_input(f"Buts {chosen['away']}", min_value=0, max_value=30, value=0, step=1, key=f"final_a_{chosen_id}")
            if st.button("Enregistrer le score final", use_container_width=True):
                conn.execute("UPDATE match_history SET home_goals=?, away_goals=?, result_status='Réglé' WHERE id=?",
                             (int(final_h), int(final_a), int(chosen_id)))
                conn.commit()
                st.success("Score final enregistré.")
                st.rerun()

    st.subheader("Tableau historique")
    display_cols = ["id", "match_date", "home", "away", "home_xg", "away_xg", "selected_market", "selected_pick", "selected_odds", "selected_ev", "home_goals", "away_goals", "result_status"]
    hist_display = history[display_cols].copy()
    hist_display.columns = ["ID", "Date", "Domicile", "Extérieur", "xG dom.", "xG ext.", "Marché choisi", "Sélection", "Cote", "EV à l'enregistrement", "Buts dom.", "Buts ext.", "Statut"]
    st.dataframe(hist_display, hide_index=True, use_container_width=True)

    st.subheader("3. Résultats du backtesting")
    if settled.empty:
        st.info("Le backtesting apparaîtra après avoir enregistré des scores finaux. Pour un test utile, vise idéalement plusieurs centaines de matchs et conserve les cotes réellement observées avant le coup d'envoi.")
    else:
        valid_picks = settled.dropna(subset=["selected_market", "selected_pick", "selected_odds"])
        evaluated = []
        for r in valid_picks.itertuples():
            won = result_for_pick(r.selected_market, r.selected_pick, int(r.home_goals), int(r.away_goals))
            stake = 1000.0  # fixed simulated stake in XAF per historical selection
            net = stake * (float(r.selected_odds)-1) if won else -stake
            evaluated.append({"ID": r.id, "Match": f"{r.home} — {r.away}", "Sélection": f"{r.selected_market}: {r.selected_pick}", "Cote": float(r.selected_odds), "Gagné": won, "Mise simulée (FCFA)": stake, "Net simulé (FCFA)": net})
        eval_df = pd.DataFrame(evaluated)
        if not eval_df.empty:
            n = len(eval_df)
            wins = int(eval_df["Gagné"].sum())
            staked = float(eval_df["Mise simulée (FCFA)"].sum())
            net = float(eval_df["Net simulé (FCFA)"].sum())
            roi = net / staked * 100 if staked else 0
            m1, m2, m3, m4 = st.columns(4)
            m1.metric("Sélections réglées", n)
            m2.metric("Taux de réussite", f"{wins/n*100:.1f}%")
            m3.metric("Bilan net simulé", f"{net:+,.0f} FCFA")
            m4.metric("ROI simulé", f"{roi:+.1f}%")
            st.caption("Simulation à mise fixe de 1 000 FCFA par match, sur la sélection ayant le meilleur EV estimé au moment de l'enregistrement. Ce choix est enregistré avant le résultat; il ne représente pas un conseil de mise. Résultats historiques ≠ performances futures.")
            st.dataframe(eval_df, hide_index=True, use_container_width=True)
            st.download_button("Télécharger les résultats du backtesting", eval_df.to_csv(index=False).encode("utf-8-sig"), "matchlab_backtesting.csv", "text/csv", use_container_width=True)

    st.subheader("4. Sauvegarde et restauration des données")
    export_df = get_history_df(conn)
    st.download_button("⬇️ Exporter tout l'historique en CSV", export_df.to_csv(index=False).encode("utf-8-sig"), "matchlab_historique_complet.csv", "text/csv", use_container_width=True)
    upload_history = st.file_uploader("Restaurer un CSV précédemment exporté par MatchLab", type=["csv"], key="restore_history_csv")
    if upload_history is not None:
        if st.button("Importer / fusionner l'historique CSV"):
            try:
                imported = pd.read_csv(upload_history)
                required_cols = {"saved_at", "match_date", "home", "away", "home_xg", "away_xg", "probabilities_json", "odds_json"}
                if not required_cols.issubset(imported.columns):
                    st.error("Ce CSV ne semble pas être un export complet de MatchLab v5.")
                else:
                    count = 0
                    for _, row in imported.iterrows():
                        conn.execute("""INSERT INTO match_history
                            (saved_at, match_date, home, away, home_xg, away_xg, probabilities_json, odds_json,
                             selected_market, selected_pick, selected_odds, selected_probability, selected_ev,
                             home_goals, away_goals, result_status)
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                            (str(row.get("saved_at", datetime.now().isoformat(timespec="seconds"))), str(row["match_date"]),
                             str(row["home"]), str(row["away"]), float(row["home_xg"]), float(row["away_xg"]),
                             str(row["probabilities_json"]), str(row["odds_json"]),
                             None if pd.isna(row.get("selected_market")) else str(row.get("selected_market")),
                             None if pd.isna(row.get("selected_pick")) else str(row.get("selected_pick")),
                             None if pd.isna(row.get("selected_odds")) else float(row.get("selected_odds")),
                             None if pd.isna(row.get("selected_probability")) else float(row.get("selected_probability")),
                             None if pd.isna(row.get("selected_ev")) else float(row.get("selected_ev")),
                             None if pd.isna(row.get("home_goals")) else int(row.get("home_goals")),
                             None if pd.isna(row.get("away_goals")) else int(row.get("away_goals")),
                             str(row.get("result_status", "À régler"))))
                        count += 1
                    conn.commit()
                    st.success(f"{count} lignes importées. Les lignes sont ajoutées; l'import n'élimine pas les doublons.")
                    st.rerun()
            except Exception as e:
                st.error(f"Échec de l'import : {e}")
else:
    st.info("Ton historique est vide. Enregistre une analyse ci-dessus, puis saisis le score final après le match.")

st.caption("MatchLab Football v5 · Historique local SQLite + export CSV. Sur un hébergement gratuit, le stockage local peut être réinitialisé lors de certaines opérations : télécharge régulièrement une sauvegarde CSV.")
conn.close()
